"""
a simple package that does nothing
"""
        
__version__ = '0.0.2'

        
